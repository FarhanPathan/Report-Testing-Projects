﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using BankAccountDataAccess;

namespace BankWebAPIProject.Controllers
{
    public class AccountsController : ApiController
    {

        public IEnumerable<BankAccount> Get()
        {
            using (bankEntities entities = new bankEntities())
            {
                return entities.BankAccounts.ToList();
            }
        }

        public BankAccount Get(int id)
        {
            using (bankEntities entities = new bankEntities())
            {
                return entities.BankAccounts.FirstOrDefault(s => s.AccountNo == id);
            }
        }

        public BankAccount Get(string name)
        {
            using (bankEntities entities = new bankEntities())
            {
                return entities.BankAccounts.FirstOrDefault(s => s.Name == name);
            }
        }

    }
}
